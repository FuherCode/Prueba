package com.localmusic.player

import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken

class MainActivity : ComponentActivity() {
    private var tracks by mutableStateOf<List<MusicTrack>>(emptyList())
    private var controller by mutableStateOf<MediaController?>(null)
    private var permissionGranted by mutableStateOf(false)

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            permissionGranted = granted
            if (granted) scanMusic()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        connectPlaybackService()
        val permission = if (Build.VERSION.SDK_INT >= 33)
            Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

        permissionGranted = ContextCompat.checkSelfPermission(this, permission) ==
            PackageManager.PERMISSION_GRANTED
        if (permissionGranted) scanMusic() else permissionLauncher.launch(permission)

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = androidx.compose.ui.graphics.Color(0xFFB8C5FF),
                    background = androidx.compose.ui.graphics.Color(0xFF101116),
                    surface = androidx.compose.ui.graphics.Color(0xFF191A20)
                )
            ) {
                LocalMusicScreen(
                    tracks = tracks,
                    hasPermission = permissionGranted,
                    onRequestPermission = { permissionLauncher.launch(permission) },
                    onPlay = { index -> playFrom(index) },
                    player = controller
                )
            }
        }
    }

    private fun scanMusic() {
        tracks = MusicRepository(this).loadTracks()
    }

    private fun connectPlaybackService() {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener(
            { controller = future.get() },
            ContextCompat.getMainExecutor(this)
        )
    }

    private fun playFrom(index: Int) {
        val player = controller ?: return
        val items = tracks.map {
            MediaItem.Builder()
                .setMediaId(it.id.toString())
                .setUri(it.uri)
                .setMediaMetadata(
                    androidx.media3.common.MediaMetadata.Builder()
                        .setTitle(it.title)
                        .setArtist(it.artist)
                        .setAlbumTitle(it.album)
                        .build()
                ).build()
        }
        player.setMediaItems(items, index, 0L)
        player.prepare()
        player.play()
    }

    override fun onDestroy() {
        controller?.release()
        controller = null
        super.onDestroy()
    }
}

@Composable
private fun LocalMusicScreen(
    tracks: List<MusicTrack>,
    hasPermission: Boolean,
    onRequestPermission: () -> Unit,
    onPlay: (Int) -> Unit,
    player: MediaController?
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(tracks, query) {
        tracks.filter {
            it.title.contains(query, true) || it.artist.contains(query, true) ||
                it.album.contains(query, true)
        }
    }
    var currentTitle by remember { mutableStateOf("Nada reproduciéndose") }
    LaunchedEffect(player) {
        while (true) {
            currentTitle = player?.currentMediaItem?.mediaMetadata?.title?.toString()
                ?: "Nada reproduciéndose"
            kotlinx.coroutines.delay(500)
        }
    }

    Scaffold(
        bottomBar = {
            Surface(tonalElevation = 5.dp) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(currentTitle, fontWeight = FontWeight.SemiBold, maxLines = 1)
                        Text(
                            if (player?.isPlaying == true) "Reproduciendo" else "En pausa",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = { player?.seekToPreviousMediaItem() }) {
                        Icon(Icons.Default.SkipPrevious, "Anterior")
                    }
                    IconButton(onClick = {
                        if (player?.isPlaying == true) player.pause() else player?.play()
                    }) {
                        Icon(
                            if (player?.isPlaying == true) Icons.Default.Pause else Icons.Default.PlayArrow,
                            "Reproducir o pausar"
                        )
                    }
                    IconButton(onClick = { player?.seekToNextMediaItem() }) {
                        Icon(Icons.Default.SkipNext, "Siguiente")
                    }
                }
            }
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp)
        ) {
            Spacer(Modifier.height(24.dp))
            Text("LOCAL MUSIC", style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary)
            Text("Tu música.", style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(16.dp))

            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Buscar canciones, artistas o álbumes") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                singleLine = true,
                shape = RoundedCornerShape(18.dp)
            )
            Spacer(Modifier.height(18.dp))

            if (!hasPermission) {
                Text("Local Music necesita permiso para leer tus archivos de audio.")
                Button(onClick = onRequestPermission) { Text("Conceder permiso") }
            } else {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Canciones", style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    Text("${filtered.size}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Spacer(Modifier.height(8.dp))
                if (filtered.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("No se encontraron canciones locales.")
                    }
                } else {
                    LazyColumn(contentPadding = PaddingValues(bottom = 20.dp)) {
                        items(filtered) { track ->
                            val index = tracks.indexOf(track)
                            Row(
                                Modifier.fillMaxWidth()
                                    .clickable { onPlay(index) }
                                    .padding(vertical = 11.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant
                                ) {
                                    Icon(Icons.Default.MusicNote, null,
                                        Modifier.padding(13.dp))
                                }
                                Spacer(Modifier.width(13.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(track.title, fontWeight = FontWeight.Medium,
                                        maxLines = 1)
                                    Text(
                                        "${track.artist} • ${track.album}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1
                                    )
                                }
                                IconButton(onClick = { onPlay(index) }) {
                                    Icon(Icons.Default.PlayArrow, "Reproducir")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
