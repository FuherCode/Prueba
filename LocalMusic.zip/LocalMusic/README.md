# Local Music

Reproductor Android nativo de archivos de audio locales. Proyecto inicial independiente, inspirado en la experiencia de uso de Booming Music.

## Estado de este paquete

Este ZIP contiene una **base funcional inicial**:
- Interfaz Compose oscura.
- Lectura de biblioteca local mediante MediaStore.
- Búsqueda de canciones.
- Reproducción mediante Media3 ExoPlayer.
- Servicio MediaSession para integración con controles multimedia del sistema.
- Controles básicos anterior / reproducir / siguiente.

No debe considerarse todavía una versión completa de producción. Las funciones previstas como Room persistente, favoritos, playlists editables, letras LRC, ecualizador propio, escaneo de carpetas y temporizador deben implementarse y probarse en iteraciones posteriores.

## Requisitos

- Android Studio reciente.
- JDK 17.
- Android SDK 36.
- Conexión a Internet durante la primera sincronización Gradle para descargar dependencias.

## Abrir y compilar

1. Descomprimir `LocalMusic.zip`.
2. Abrir la carpeta `LocalMusic` desde Android Studio.
3. Esperar la sincronización de Gradle.
4. Conectar un teléfono Android o iniciar un emulador.
5. Ejecutar la configuración `app`.

Para generar APK debug desde Android Studio, abrir la ventana **Gradle** y ejecutar:

`LocalMusic > app > Tasks > build > assembleDebug`

También puede ejecutarse desde una terminal si Gradle está instalado:

```bash
gradle assembleDebug
```

APK resultante:

`app/build/outputs/apk/debug/app-debug.apk`

Para generar APK release:

```bash
./gradlew assembleRelease
```

La APK release debe firmarse con una clave propia antes de distribuirla. No publiques una APK release sin revisar la configuración de firma.

## Identidad de la app

- Nombre: Local Music
- Application ID: `com.localmusic.player`
- Min SDK: 26 (Android 8.0)
- Target SDK: 36

## Permisos

La app solicita acceso a archivos de audio para indexar la biblioteca. Android 13 o superior utiliza `READ_MEDIA_AUDIO`. No se declara permiso de Internet en el manifiesto.

## Próximas etapas recomendadas

1. Probar compilación y reproducción en dispositivos reales.
2. Añadir pantalla de reproducción completa y carátulas.
3. Añadir Room: favoritos, historial y listas.
4. Añadir selector SAF para carpetas específicas y exclusiones.
5. Añadir temporizador, letras LRC y ecualizador usando AudioEffects de Android.
6. Añadir pruebas, accesibilidad, manejo de errores y optimización.
7. Revisar permisos y comportamiento en Android 8–16.

## Licencia

El código de esta base inicial se entrega bajo MIT. Media3, AndroidX y demás dependencias conservan sus respectivas licencias. Este proyecto no incorpora código fuente de Booming Music.
